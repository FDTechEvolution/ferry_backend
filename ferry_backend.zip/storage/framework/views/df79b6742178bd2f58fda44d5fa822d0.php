

<?php $__env->startSection('page-title'); ?>
    <h1 class="ms-2 mb-0" id="route-page-title"><span class="text-main-color-2">Route</span> control</h1>
    <a href="<?php echo e(route('route-create')); ?>" class="btn button-green-bg border-radius-10 ms-3 btn-sm w--15">Add</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-option'); ?>
<div class="route-search d-none">
    <div class="row pt-2">
        <div class="col-9">
            <div class="mb-1 row">
                    <label for="station-search-from" class="col-form-label form-label-sm col-sm-4 custom-padding">Station From* </label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control form-control-sm" id="station-search-from">
                    </div>
            </div>
            <div class="mb-1 row">
                    <label for="station-search-to" class="col-form-label form-label-sm col-sm-4 custom-padding">Station to </label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control form-control-sm col-sm-10" id="station-search-to">
                    </div>
            </div>
        </div>
        <div class="col-3">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-orange','data' => ['type' => _('button'),'text' => _('search')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-orange'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('button')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('search'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-12">
        
    </div>

    <div class="col-12">
        <div id="to-route-list">
            <div class="card-body w--90 mx-auto">
                <h1>Route control</h1>
                <table class="table-datatable table table-datatable-custom" id="route-datatable" 
                    data-lng-empty="No data available in table"
                    data-lng-page-info="Showing _START_ to _END_ of _TOTAL_ entries"
                    data-lng-filtered="(filtered from _MAX_ total entries)"
                    data-lng-loading="Loading..."
                    data-lng-processing="Processing..."
                    data-lng-search="Search..."
                    data-lng-norecords="No matching records found"
                    data-lng-sort-ascending=": activate to sort column ascending"
                    data-lng-sort-descending=": activate to sort column descending"

                    data-enable-col-sorting="false"
                    data-items-per-page="15"

                    data-enable-column-visibility="false"
                    data-enable-export="true"
                    data-lng-export="<i class='fi fi-squared-dots fs-5 lh-1'></i>"
                    data-lng-pdf="PDF"
                    data-lng-xls="XLS"
                    data-lng-all="All"
                    data-export-pdf-disable-mobile="true"
                    data-export='["pdf", "xls"]'
                >
                    <thead>
                        <tr>
                            <th class="text-center d-none" style="width: 60px;">Choose</th>
                            <th class="text-start">Station From</th>
                            <th class="text-start">Station To</th>
                            <th class="text-center">Depart</th>
                            <th class="text-center">Arrive</th>
                            <th class="text-center fix-width-120">Icon</th>
                            <th class="text-center">Price</th>
                            <th class="text-center">status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td class="d-none">
                                    <input class="form-check-input form-check-input-primary" type="checkbox" value="" id="route-check-<?php echo e($index); ?>">
                                </td>
                                <td class="text-start" style="line-height: 1.2rem;">
                                    <?php echo e($route['station_from']['name']); ?>

                                    <?php if($route['station_from']['piername'] != ''): ?>
                                        <small class="text-secondary fs-d-80">(<?php echo e($route['station_from']['piername']); ?>)</small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-start" style="line-height: 1.2rem;">
                                    <?php echo e($route['station_to']['name']); ?>

                                    <?php if($route['station_to']['piername'] != ''): ?>
                                        <small class="text-secondary fs-d-80">(<?php echo e($route['station_to']['piername']); ?>)</small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date('H:i', strtotime($route['depart_time']))); ?></td>
                                <td><?php echo e(date('H:i', strtotime($route['arrive_time']))); ?></td>
                                <td>
                                    <div class="row mx-auto justify-center-custom">
                                        <?php $__currentLoopData = $route['icons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-4 px-0" style="max-width: 40px;">
                                            <img src="<?php echo e($icon['path']); ?>" class="w-100">
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </td>
                                <td><?php echo e(number_format($route['regular_price'])); ?></td>
                                <td><?php echo $route_status[$route['isactive']]; ?></td>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-edit','data' => ['class' => 'me-2','url' => route('route-edit', ['id' => $route['id']]),'id' => 'btn-route-edit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('action-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'me-2','url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('route-edit', ['id' => $route['id']])),'id' => 'btn-route-edit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-delete','data' => ['url' => route('route-delete', ['id' => $route['id']]),'message' => _('Are you sure? Delete this route ?')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('action-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('route-delete', ['id' => $route['id']])),'message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Are you sure? Delete this route ?'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
    .custom-padding {
        padding-top: 9px;
        padding-bottom: 8px;
    }
    .fix-width-120 {
        width: 120px;
    }
    
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const icons = <?php echo e(Js::from($icons)); ?>

</script>
<script src="<?php echo e(asset('assets/js/app/route_control.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Git\ferry_backend\resources\views/pages/route_control/index.blade.php ENDPATH**/ ?>