@extends('layouts.default')

@section('content')
    <div id="app"></div>
    @vite('resources/js/app.js')
@stop