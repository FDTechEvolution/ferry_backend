<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['text' => '', 'bg' => '', 'route' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['text' => '', 'bg' => '', 'route' => '']); ?>
<?php foreach (array_filter((['text' => '', 'bg' => '', 'route' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a href="<?php echo e($route); ?>">
    <div class="section w-100" style="background-color: <?php echo e($bg); ?>6b">
        <div class="d-flex w-100 align-items-center text-center">
            <span class="w-100 display-6 text-light fw-bold">
                <?php echo e($text); ?>

            </span>
        </div>
    </div>
</a><?php /**PATH D:\Work\Git\ferry_backend\resources\views/components/dashboard-section-manage.blade.php ENDPATH**/ ?>