

<?php $__env->startSection('page-title'); ?>
    <h1 class="ms-2 mb-0" id="route-page-title"><span class="text-main-color-2">Add</span> new Route</h1>
    <div class="route-search d-none">
        <div class="mb-3">
            <label for="station-from" class="form-label">Station From* </label>
            <input type="text" class="form-control" id="station-from">
        </div>
        <div class="mb-3">
            <label for="station-to" class="form-label">Station to </label>
            <input type="text" class="form-control" id="station-to">
        </div>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-orange','data' => ['type' => _('button'),'text' => _('search')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-orange'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('button')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('search'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-12">
        <form novalidate class="bs-validate" id="route-create-form" method="POST" action="<?php echo e(route('route-store')); ?>">
            <?php echo csrf_field(); ?>
            <fieldset id="route-create">
                <div class="row bg-transparent mt-5">
                    <div class="col-sm-12 w-75 mx-auto">

                        <div class="row">
                            <div class="col-12 px-4">
                                <h1 class="fw-bold text-main-color-2 mb-4">Add new Route</h1>

                                <div class="mb-4 w-75 row">
                                    <label class="col-sm-3 col-form-label-sm text-start fw-bold">Station From* :</label>
                                    <div class="col-sm-9">
                                        <select required class="form-select form-select-sm" id="station-from-selected" name="station_from">
                                            <option value="" selected disabled>--- Choose ---</option>
                                            <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($station['id']); ?>"><?php echo e($station['name']); ?> <?php if($station['piername'] != ''): ?> [<?php echo e($station['piername']); ?>] <?php endif; ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-4 w-75 row">
                                    <label class="col-sm-3 col-form-label-sm text-start fw-bold">Station To* :</label>
                                    <div class="col-sm-9">
                                        <select required class="form-select form-select-sm" id="station-to-selected" name="station_to">
                                            <option value="" selected disabled>--- Choose ---</option>
                                            <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($station['id']); ?>"><?php echo e($station['name']); ?> <?php if($station['piername'] != ''): ?> [<?php echo e($station['piername']); ?>] <?php endif; ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-0 pb-0 row">
                                    <label class="col-sm-4 col-form-label-sm text-start">More detail</label>
                                </div>
                                <div class="mb-2 row">
                                    <div class="col-2">
                                        <label class="col-form-label-sm text-start fw-bold">Depart Time</label>
                                        <input type="time" name="depart_time" class="form-control form-control-sm">
                                    </div>
                                    <div class="col-2">
                                        <label class="col-form-label-sm text-start fw-bold">Arrive Time</label>
                                        <input type="time" name="arrive_time" class="form-control form-control-sm">
                                    </div>
                                    <div class="col-2">
                                        <label for="regular-price" class="col-form-label-sm text-start fw-bold">Regular Price</label>
                                        <input type="number" class="form-control form-control-sm" id="regular-price" name="regular_price">
                                    </div>
                                    <div class="col-2">
                                        <label for="child-price" class="col-form-label-sm text-start fw-bold">Child</label>
                                        <input type="number" class="form-control form-control-sm" id="child-price" name="child_price">
                                    </div>
                                    <div class="col-2">
                                        <label for="extra" class="col-form-label-sm text-start fw-bold">Extra</label>
                                        <select class="form-control form-control-sm" id="extra" name="extra">

                                        </select>
                                    </div>
                                    <div class="col-2">
                                        <label for="infant" class="col-form-label-sm text-start fw-bold">Infant</label>
                                        <select class="form-control form-control-sm" id="infant" name="infant">
                                            
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-3">
                                        <label class="col-form-label-sm text-start fw-bold">Icon <small class="text-danger d-none" id="icon-notice">MAX!</small></label>
                                        <div class="dropdown">
                                            <a class="btn btn-outline-dark btn-sm dropdown-toggle w-100" href="#" role="button" id="dropdownIcons" data-bs-toggle="dropdown" aria-expanded="false" data-bs-offset="0,6">
                                                Select icon
                                                <span class="group-icon">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18px" height="18px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <polyline points="6 9 12 15 18 9"></polyline>
                                                    </svg>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18px" height="18px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <line x1="18" y1="6" x2="6" y2="18"></line>
                                                        <line x1="6" y1="6" x2="18" y2="18"></line>
                                                    </svg>
                                                </span>
                                            </a>

                                            <ul class="dropdown-menu shadow-lg p-1 w-100" aria-labelledby="dropdownIcons">
                                                <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li id="icon-active-<?php echo e($index); ?>">
                                                        <a class="dropdown-item rounded" href="javascript:void(0)" onClick="addRouteIcon(<?php echo e($index); ?>)">
                                                            <img src="<?php echo e(asset($icon->path)); ?>" class="me-2" width="24" height="24">
                                                            <span><?php echo e($icon->name); ?></span>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-9 show-icon">
                                        <label class="col-form-label-sm text-start fw-bold"></label>
                                        <ul class="list-group list-group-horizontal">
                                        </ul>
                                        <input type="hidden" name="icons" id="route-add-icon" value="">
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-4">
                                        <label class="d-flex align-items-center mb-1">
                                            <span class="user-select-none fw-bold me-2">Master From </span>
                                            <input class="d-none-cloaked" type="checkbox" id="master-from-switch" name="master_from_on" value="1">
                                            <i class="switch-icon switch-icon-primary switch-icon-xs"></i>
                                            <span class="ms-1 user-select-none" id="master-from-text">Off</span>
                                        </label>

                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-route-select-infomation','data' => ['header' => _('Master From'),'selectId' => _('station-from-selected'),'type' => _('from')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-route-select-infomation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Master From')),'select_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('station-from-selected')),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('from'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div>

                                    <div class="col-4">
                                        <label class="d-flex align-items-center mb-1">
                                            <span class="user-select-none fw-bold me-2">Master To </span>
                                            <input class="d-none-cloaked" type="checkbox" id="master-to-switch" name="master_to_on" value="1">
                                            <i class="switch-icon switch-icon-primary switch-icon-xs"></i>
                                            <span class="ms-1 user-select-none" id="master-to-text">Off</span>
                                        </label>

                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-route-select-infomation','data' => ['header' => _('Master To'),'selectId' => _('station-to-selected'),'type' => _('to')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-route-select-infomation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Master To')),'select_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('station-to-selected')),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('to'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-4">
                                        <label class="d-flex align-items-center mb-1 fw-bold">
                                            Infomation From 
                                            <i class="fi fi-round-plus text-main-color-2 ms-2"></i>
                                            <i class="fi fi-round-close text-main-color-2 ms-2"></i>
                                        </label>

                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-route-select-infomation','data' => ['header' => _('Infomation From'),'selectId' => _('station-from-selected'),'type' => _('from')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-route-select-infomation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Infomation From')),'select_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('station-from-selected')),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('from'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div>

                                    <div class="col-4">
                                        <label class="d-flex align-items-center mb-1 fw-bold">
                                            Infomation To 
                                            <i class="fi fi-round-plus text-main-color-2 ms-2"></i>
                                            <i class="fi fi-round-close text-main-color-2 ms-2"></i>
                                        </label>

                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-route-select-infomation','data' => ['header' => _('Infomation To'),'selectId' => _('station-to-selected'),'type' => _('to')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-route-select-infomation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Infomation To')),'select_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('station-to-selected')),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('to'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <label class="col-sm-2 text-start fw-bold">Status :</label>
                                    <div class="col-sm-2">
                                        <label class="d-flex align-items-center mb-3">
                                            <input class="d-none-cloaked" type="checkbox" id="route-status-switch" name="status" value="1" checked>
                                            <i class="switch-icon switch-icon-primary"></i>
                                            <span class="px-3 user-select-none" id="route-status-text">On</span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 mt-4">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-submit-loading','data' => ['class' => 'btn-lg w--20 me-4 button-orange-bg','formId' => _('route-create-form'),'fieldsetId' => _('route-create'),'text' => _('Add')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-submit-loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-lg w--20 me-4 button-orange-bg','form_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('route-create-form')),'fieldset_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('route-create')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Add'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <a href="<?php echo e(route('route-index')); ?>" class="btn btn-secondary btn-lg w--20">Cancel</a>
                                <small id="user-create-error-notice" class="text-danger mt-3"></small>
                            </div>
                        </div>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>

<style>
    .icon-del-style {
        position: absolute;
        right: 10px;
        top: -5px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-info','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-create-infomation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-create-infomation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const icons = <?php echo e(Js::from($icons)); ?>

    const stations = <?php echo e(Js::from($stations)); ?>

    // const info_lines = <?php echo e(Js::from($station['info_line'])); ?>

</script>
<script src="<?php echo e(asset('assets/js/app/route_control.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Git\ferry_backend\resources\views/pages/route_control/create.blade.php ENDPATH**/ ?>