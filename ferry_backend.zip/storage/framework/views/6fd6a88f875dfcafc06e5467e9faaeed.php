<div class="row bg-transparent mt-2">
    <div class="ms-5 mb-3">
        <button class="btn btn-secondary" id="btn-section-cancel-manage">< Back</button>
    </div>
    <div class="col-12 w--90 mx-auto">
        <div id="to-section-list">
            <div class="card-body">
                <table class="table-datatable table table-datatable-custom" id="section-datatable" 
                    data-lng-empty="No data available in table"
                    data-lng-page-info="Showing _START_ to _END_ of _TOTAL_ entries"
                    data-lng-filtered="(filtered from _MAX_ total entries)"
                    data-lng-loading="Loading..."
                    data-lng-processing="Processing..."
                    data-lng-search="Search..."
                    data-lng-norecords="No matching records found"
                    data-lng-sort-ascending=": activate to sort column ascending"
                    data-lng-sort-descending=": activate to sort column descending"

                    data-enable-col-sorting="false"
                    data-items-per-page="15"

                    data-enable-column-visibility="false"
                    data-enable-export="true"
                    data-lng-export="<i class='fi fi-squared-dots fs-5 lh-1'></i>"
                    data-lng-pdf="PDF"
                    data-lng-xls="XLS"
                    data-lng-all="All"
                    data-export-pdf-disable-mobile="true"
                    data-export='["pdf", "xls"]'
                >
                    <thead>
                        <tr>
                            <th class="text-center w--5">#</th>
                            <th>name</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($index +1); ?></td>
                                <td id="section-name-<?php echo e($index); ?>" class="text-start"><?php echo e($section['name']); ?></td>
                                <td>
                                    <input type="hidden" name="section_id" id="section-id-<?php echo e($index); ?>" value="<?php echo e($section['id']); ?>">
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-edit','data' => ['class' => 'me-2','url' => _('javascript:void(0)'),'id' => 'btn-section-edit','onClick' => 'updateSectionEditData('.e($index).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('action-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'me-2','url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('javascript:void(0)')),'id' => 'btn-section-edit','onClick' => 'updateSectionEditData('.e($index).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-delete','data' => ['url' => route('section-delete', ['id' => $section['id']]),'message' => _('Are you sure? Delete '. $section['name'] .'?')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('action-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('section-delete', ['id' => $section['id']])),'message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Are you sure? Delete '. $section['name'] .'?'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="to-section-edit" class="m-auto d-none">
            <form novalidate class="bs-validate" id="section-edit-form" method="POST" action="<?php echo e(route('section-update')); ?>">
                <?php echo csrf_field(); ?>
                <fieldset id="section-edit">
                    <div class="row bg-transparent mt-5">
                        <div class="col-sm-6 mx-auto">
                            <h1 class="fw-bold text-second-color mb-4">Section edit</h1>

                            <div class="mb-4 row">
                                <label for="section-name-edit" class="col-sm-3 col-form-label-sm text-start">Section* :</label>
                                <div class="col-sm-9">
                                    <input type="text" required class="form-control form-control-sm" id="section-name-edit" name="name" value="">
                                </div>
                            </div>

                            <div class="text-center mt-5">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-submit-loading','data' => ['class' => 'btn-lg w--30 me-5','formId' => _('section-edit-form'),'fieldsetId' => _('section-edit'),'text' => _('Edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-submit-loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-lg w--30 me-5','form_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('section-edit-form')),'fieldset_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('section-edit')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Edit'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <button type="button" class="btn btn-secondary btn-lg w--30" id="btn-section-cancel-edit">Cancel</button>
                                <small id="section-edit-error-notice" class="text-danger mt-3"></small>
                            </div>
                        </div>
                        <input type="hidden" name="section_id" id="section-id-edit" value="">
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
</div><?php /**PATH D:\Work\Git\ferry_backend\resources\views/pages/stations/section_manage.blade.php ENDPATH**/ ?>