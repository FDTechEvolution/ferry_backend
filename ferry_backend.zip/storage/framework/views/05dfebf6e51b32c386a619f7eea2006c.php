<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type' => '', 'text' => '', 'form_id' => '', 'fieldset_id' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => '', 'text' => '', 'form_id' => '', 'fieldset_id' => '']); ?>
<?php foreach (array_filter((['type' => '', 'text' => '', 'form_id' => '', 'fieldset_id' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $buttonId = uniqid();
    $iconBeforeClickId = uniqid();
    $iconAfterClickId = uniqid();
?>

<button type="<?php echo e($type); ?>" data-button-id="<?php echo e($buttonId); ?>" <?php echo e($attributes->merge(['class' => 'btn button-green-bg border-radius-10'])); ?>>
    <span><?php echo e($text); ?></span>
    <i data-icon-after-click-id="<?php echo e($iconAfterClickId); ?>" class="fi fi-loading-dots fi-spin d-none"></i>
</button>

<script type="text/javascript" defer="true">
    document.addEventListener("DOMContentLoaded", function() {
        const button = document.querySelector("[data-button-id='<?php echo e($buttonId); ?>']")
        const icon_arter = document.querySelector("[data-icon-after-click-id='<?php echo e($iconAfterClickId); ?>']")
        const form_id = document.querySelector("#<?php echo e($form_id); ?>")
        const fieldset_id = document.querySelector("#<?php echo e($fieldset_id); ?>")

        if (button instanceof HTMLElement) {
            button.addEventListener("click", function() {
                if(form_id.checkValidity()){
                    form_id.submit()
                    icon_arter.classList.remove('d-none')
                    fieldset_id.disabled = true
                }
            });

            // or do whatever needed to initialize the button...
        }
    })
</script><?php /**PATH D:\Work\Git\ferry_backend\resources\views/components/button-loading.blade.php ENDPATH**/ ?>