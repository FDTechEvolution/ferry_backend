<div class="prow">

    <table class="w-100 ptable ">
        <tr>
            <td style="white-space:wrap;font-size: 9px;">
                <small><strong>Terms and Conditions</strong></small><br>
                <?= $term['body'] ?>
            </td>
        </tr>
    </table>
</div>