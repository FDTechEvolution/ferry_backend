<form novalidate class="bs-validate" id="user-edit-form" method="POST" onSubmit="return checkValidate()" action="<?php echo e(route('user-update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row bg-transparent mt-5">
        <div class="col-sm-12 w-75 mx-auto">
            <h1 class="fw-bold text-second-color mb-4">Edit account</h1>
            
            <div class="mb-3 row">
                <label for="username" class="col-sm-2 col-form-label-sm text-start">Username* :</label>
                <div class="col-sm-10 ps-3">
                    <img id="edit-user-avatar" src="" class="rounded-circle shadow ms-2" style="width: 42px; height: 38px;" />
                    <span class="mb-0 ms-2" id="edit-username-data" style="line-height: 40px;"></span>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="firstname" class="col-sm-2 col-form-label-sm text-start">Name* :</label>
                <div class="col-sm-10">
                    <input type="text" required class="form-control form-control-sm" id="edit-firstname" name="firstname" value="">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="lastname" class="col-sm-2 col-form-label-sm text-start">Last name* :</label>
                <div class="col-sm-10">
                    <input type="text" required class="form-control form-control-sm" id="edit-lastname" name="lastname" value="">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="office" class="col-sm-2 col-form-label-sm text-start">Office* :</label>
                <div class="col-sm-10">
                    <input type="text" required class="form-control form-control-sm" id="edit-office" name="office" value="">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="email" class="col-sm-2 col-form-label-sm text-start">email* :</label>
                <div class="col-sm-10">
                    <input type="email" required class="form-control form-control-sm" id="edit-email" name="email" value="">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="role" class="col-sm-2 col-form-label-sm text-start">Role :</label>
                <div class="col-sm-10">
                    <select class="form-select form-select-sm" name="role" id="edit-role">
                        <option value="" selected disabled>-- select --</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role['id']); ?>"><?php echo e($role['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="file_picture" class="col-sm-2 col-form-label-sm text-start">Picture :</label>
                <div class="col-sm-10">
                    <div class="mb-3">
                        <input class="form-control form-control-sm" id="edit-file_picture" type="file" name="file">
                    </div>
                </div>
            </div>
            <input type="hidden" name="id" id="user-edit-id" />
        </div>
        <div class="col-12 text-center mt-4">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-green','data' => ['type' => _('submit'),'text' => _('Edit'),'class' => 'btn-lg w--10 me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-green'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('submit')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Edit')),'class' => 'btn-lg w--10 me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <button type="button" class="btn btn-secondary btn-lg w--10" id="btn-cancel-edit">Cancel</button>
            <small id="user-create-error-notice" class="text-danger mt-3"></small>
        </div>
    </div>
</form><?php /**PATH D:\Work\Git\ferry_backend\resources\views/pages/users/edit2.blade.php ENDPATH**/ ?>