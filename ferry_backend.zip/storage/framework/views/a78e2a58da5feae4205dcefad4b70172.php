<div class="modal fade" id="create-infomation" style="z-index: 1061;" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel3" aria-hidden="true">
	<div class="modal-dialog modal-dialog-scrollable modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Add new station infomation</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
                <div class="row">
                    <div class="col-12 px-4">
                        <div class="mb-3 row">
                            <label for="station-info-name" class="col-sm-2 col-form-label-sm text-start">Name* :</label>
                            <div class="col-sm-8">
                                <input required type="text" class="form-control form-control-sm" id="station-info-name" name="name">
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label class="col-sm-2 col-form-label-sm text-start">Detail* :</label>
                            <div class="col-sm-8">
                                <div class="quill-editor"
                                    data-ajax-url="_ajax/demo.summernote.php"
                                    data-ajax-params="['action','upload']['param2','value2']"
                                    data-textarea-name="detail"
                                    data-quill-config='{
                                        "modules": {
                                            "toolbar": [
                                                [{ "header": [2, 3, 4, 5, 6, false] }],
                                                ["bold", "italic", "underline", "strike"],
                                                [{ "color": [] }, { "background": [] }],
                                                [{ "script": "super" }, { "script": "sub" }],
                                                ["blockquote"],
                                                [{ "list": "ordered" }, { "list": "bullet"}, { "indent": "-1" }, { "indent": "+1" }],
                                                [{ "align": [] }],
                                                ["link", "image", "video"],
                                                ["clean", "code-block"]
                                            ]
                                        },

                                        "placeholder": "Type here..."
                                    }'>
                                    <p></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 text-center mt-6">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-submit-loading','data' => ['class' => 'btn-lg w--10 me-5','formId' => _('station-info-create-form'),'fieldsetId' => _('station-info-create'),'text' => _('Add')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-submit-loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-lg w--10 me-5','form_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('station-info-create-form')),'fieldset_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('station-info-create')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Add'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <button type="button" class="btn btn-secondary btn-lg w--10" id="btn-cancel-create">Cancel</button>
                        <small id="station-info-create-error-notice" class="text-danger mt-3"></small>
                    </div>
                </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div><?php /**PATH D:\Work\Git\ferry_backend\resources\views/components/modal-create-infomation.blade.php ENDPATH**/ ?>