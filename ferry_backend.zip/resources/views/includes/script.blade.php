<!-- Core javascripts -->
<script src="{{ asset('assets/js/core.min.js') }}"></script>
<script src="{{ asset('assets/js/vendor_bundle.min.js') }}"></script>