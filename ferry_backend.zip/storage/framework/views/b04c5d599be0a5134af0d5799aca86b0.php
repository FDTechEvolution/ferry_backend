<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['url' => '', 'message' => '', 'text' => '', 'icon' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['url' => '', 'message' => '', 'text' => '', 'icon' => '']); ?>
<?php foreach (array_filter((['url' => '', 'message' => '', 'text' => '', 'icon' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a href="#"
    data-href="<?php echo e($url); ?>"
    data-ajax-confirm-mode="regular"
    data-ajax-confirm-type="primary"

    data-ajax-confirm-size="modal-md"
    data-ajax-confirm-centered="false"

    data-ajax-confirm-title="Please Confirm"
    data-ajax-confirm-body="<?php echo e($message); ?>"

    data-ajax-confirm-btn-yes-class="btn-primary"
    data-ajax-confirm-btn-yes-text="Yes"
    data-ajax-confirm-btn-yes-icon="fi fi-check"

    data-ajax-confirm-btn-no-class="btn-light"
    data-ajax-confirm-btn-no-text="Cancel"
    data-ajax-confirm-btn-no-icon="fi fi-close"
    <?php echo e($attributes->merge(['class' => 'js-ajax-confirm'])); ?> 
    />
    <i class="<?php echo e($icon); ?>"></i> <?php echo e($text); ?>

</a><?php /**PATH D:\Work\Git\ferry_backend\resources\views/components/ajax-button-confirm.blade.php ENDPATH**/ ?>