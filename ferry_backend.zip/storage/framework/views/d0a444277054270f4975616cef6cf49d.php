

<?php $__env->startSection('content'); ?>
<!-- PAGE TITLE -->
<div class="py-2 px-5">
    <header>
        <div class="row">
            <div class="col-12 d-flex">
                <img src="<?php echo e(asset('assets/images/logo_tiger_line_ferry.png')); ?>">
                <h1 class="display-1 fw-bold ms-5 text-main-color">
                    Welcome
                </h1>
            </div>
        </div>
    </header>

    <div class="row mt-7">
        <div class="col-7">
            <div class="row mt-4">
                <div class="col-4">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-section-manage','data' => ['text' => _('Account'),'bg' => _('#ADD8E6'),'route' => route('users-index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-section-manage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Account')),'bg' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#ADD8E6')),'route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('users-index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div class="col-4">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-section-manage','data' => ['text' => _('Manage'),'bg' => _('#ADD8E6'),'route' => _('#')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-section-manage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Manage')),'bg' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#ADD8E6')),'route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div class="col-4">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-section-manage','data' => ['text' => _('Booking'),'bg' => _('#ADD8E6'),'route' => _('#')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-section-manage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Booking')),'bg' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#ADD8E6')),'route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div class="col-4">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-section-manage','data' => ['text' => _('Route Stations'),'bg' => _('#ADD8E6'),'route' => _('#')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-section-manage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Route Stations')),'bg' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#ADD8E6')),'route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div class="col-4">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-section-manage','data' => ['text' => _('Report'),'bg' => _('#ADD8E6'),'route' => _('#')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-section-manage'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Report')),'bg' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#ADD8E6')),'route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('#'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div class="col-4">
                    <a href="#"
                        class = 'js-ajax-confirm'
                        data-href="<?php echo e(route('logout')); ?>"
                        data-ajax-confirm-mode="regular"
                        data-ajax-confirm-type="primary"

                        data-ajax-confirm-size="modal-md"
                        data-ajax-confirm-centered="false"

                        data-ajax-confirm-title="Please Confirm"
                        data-ajax-confirm-body="Logout?"

                        data-ajax-confirm-btn-yes-class="btn-primary"
                        data-ajax-confirm-btn-yes-text="Yes"
                        data-ajax-confirm-btn-yes-icon="fi fi-check"

                        data-ajax-confirm-btn-no-class="btn-light"
                        data-ajax-confirm-btn-no-text="Cancel"
                        data-ajax-confirm-btn-no-icon="fi fi-close" 
                    >
                        <div class="section w-100" style="background-color: #ff61006b">
                            <div class="d-flex w-100 align-items-center text-center">
                                <span class="w-100 display-6 text-light fw-bold">
                                    Logout
                                </span>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-5">
            <div class="section w-100" style="background-color: #ADD8E66b;">
                <div class="d-flex flex-wrap w-100 align-items-center text-center">
                    <span class="w-100 mt-4 display-4 fw-bold text-main-color">
                        Member Admin
                    </span>
                    <span class="w-100">
                        <div class="avatar avatar-custom rounded-circle" style="background-image:url('https://cdn.pixabay.com/photo/2016/12/19/21/36/woman-1919143_1280.jpg')"></div>
                    </span>
                    <span class="w-100 mb-4 display-4 fw-bold text-main-color">
                        admin
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    header#header {
        display: none !important;
    }
    body.layout-admin #middle {
        padding-top: 0;
    }
    .section:before {
        content: '';
        display: block;
        padding-bottom: 100%;
    }
    .section {
        border-radius: 25px !important;
        display: -webkit-inline-box;
    }
    .avatar-custom {
        height: 16rem!important;
        width: 16rem!important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Git\ferry_backend\resources\views/dashboard.blade.php ENDPATH**/ ?>