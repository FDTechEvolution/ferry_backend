<!doctype html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="layout-admin layout-padded aside-sticky" data-s2t-class="btn-primary btn-sm bg-gradient-default rounded-circle border-0">

        <div id="wrapper" class="d-flex align-items-stretch flex-column">
            <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- content -->
            <div id="wrapper_content" class="d-flex flex-fill">
                <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- main -->
                <main id="middle" class="flex-fill mx-auto py-2 background-trans border-radius-20 p-md-5" style="margin-left: 10px !important;">
                    <?php echo $__env->make('includes.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>

            <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

        <?php echo $__env->yieldContent('modal'); ?>
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html><?php /**PATH D:\Work\Git\ferry_backend\resources\views/layouts/default.blade.php ENDPATH**/ ?>