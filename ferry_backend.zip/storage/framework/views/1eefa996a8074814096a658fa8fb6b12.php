<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['header' => '', 'main_content' => '', 'sub_content' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['header' => '', 'main_content' => '', 'sub_content' => '']); ?>
<?php foreach (array_filter((['header' => '', 'main_content' => '', 'sub_content' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="section p-4">
    <h6 class="mb-0 text-muted"><?php echo e($header); ?></h6>
    <div class="d-flex align-items-center">
        <span class="w-100">
            <span class="fs-5 fw-bold mb-0"><?php echo e($main_content); ?></span>
            <small class="text-muted"><?php echo e($sub_content != '' ? '/ '.$sub_content : ''); ?></small>
        </span>
    </div>
</div><?php /**PATH D:\Work\Git\ferry_backend\resources\views/components/user-overview-section.blade.php ENDPATH**/ ?>