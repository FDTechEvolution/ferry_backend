<form novalidate class="bs-validate" id="station-info-edit-form" method="POST" action="<?php echo e(route('station-info-update')); ?>">
    <?php echo csrf_field(); ?>
    <fieldset id="station-info-edit">
        <div class="row bg-transparent mt-5">
            <div class="col-sm-12 w--80 mx-auto">
                <h1 class="fw-bold text-second-color mb-4">Edit station infomation</h1>
            
                <div class="row">
                    <div class="col-12 px-4">
                        <div class="mb-3 row">
                            <label for="edit-station-info-name" class="col-sm-2 col-form-label-sm text-start">Name* :</label>
                            <div class="col-sm-8">
                                <input required type="text" class="form-control form-control-sm" id="edit-station-info-name" name="name">
                            </div>
                        </div>

                        <!-- <div class="mb-3 row">
                            <label for="edit-station-info-type" class="col-sm-2 col-form-label-sm text-start">Type* :</label>
                            <div class="col-sm-8">
                                <select class="form-select form-select-sm" id="edit-station-info-type" name="type">
                                    <option value="" selected disabled>-- Select --</option>
                                    <option value="from">Master Info From</option>
                                    <option value="to">Master Info To</option>
                                </select>
                            </div>
                        </div> -->

                        <div class="mb-3 row">
                            <label class="col-sm-2 col-form-label-sm text-start">Detail* :</label>
                            <div class="col-sm-8" id="quill-editable">
                                <div id="station-info-edit-detail"></div>
                                <textarea class="d-none" id="edit-detail-textarea" name="detail"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 text-center mt-6">
                        <input type="hidden" id="station-info-edit-id" name="station_info_id">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-submit-loading','data' => ['class' => 'btn-lg w--10 me-5','formId' => _('station-info-edit-form'),'fieldsetId' => _('station-info-edit'),'text' => _('Edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-submit-loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-lg w--10 me-5','form_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('station-info-edit-form')),'fieldset_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('station-info-edit')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Edit'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <button type="button" class="btn btn-secondary btn-lg w--10" id="btn-cancel-edit">Cancel</button>
                        <small id="station-info-edit-error-notice" class="text-danger mt-3"></small>
                    </div>
                </div>
            </div>
        </div>
    </fieldset>
</form><?php /**PATH D:\Work\Git\ferry_backend\resources\views/pages/station_infomations/edit.blade.php ENDPATH**/ ?>