<?php if(Session::has('success')): ?>
<div class="hide toast-on-load" 
    data-toast-type="success" 
    data-toast-title="Well done! " 
    data-toast-body="<?php echo e(Session::get('success')); ?>" 
    data-toast-pos="top-end" 
    data-toast-delay="4000" 
    data-toast-fill="true">
</div>
<?php endif; ?>

<?php if(Session::has('fail')): ?>
<div class="hide toast-on-load" 
    data-toast-type="danger" 
    data-toast-title="Oh snap!" 
    data-toast-body="<?php echo e(Session::get('fail')); ?>" 
    data-toast-pos="top-end" 
    data-toast-delay="4000" 
    data-toast-fill="true">
</div>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
<div class="hide toast-on-load" 
    data-toast-type="warning" 
    data-toast-title="" 
    data-toast-body="<?php echo e(Session::get('warning')); ?>" 
    data-toast-pos="top-end" 
    data-toast-delay="4000" 
    data-toast-fill="true">
</div>
<?php endif; ?><?php /**PATH D:\Work\Git\ferry_backend\resources\views/includes/flash-message.blade.php ENDPATH**/ ?>