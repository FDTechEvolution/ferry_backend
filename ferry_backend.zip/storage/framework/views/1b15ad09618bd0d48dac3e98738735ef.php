<form novalidate class="bs-validate" id="section-create-form" method="POST" action="<?php echo e(route('section-create')); ?>">
    <?php echo csrf_field(); ?>
    <fieldset id="section-create">
        <div class="row bg-transparent mt-5">
            <div class="col-sm-4 mx-auto">
                <h1 class="fw-bold text-second-color mb-4">Add new section</h1>

                <div class="mb-4 row">
                    <label for="section-create-name" class="col-sm-3 col-form-label-sm text-start">Section* :</label>
                    <div class="col-sm-9">
                        <input type="text" required class="form-control form-control-sm" id="section-create-name" name="name" value="">
                    </div>
                </div>

                <div class="text-center mt-5">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-submit-loading','data' => ['class' => 'btn-lg w--30 me-5','formId' => _('section-create-form'),'fieldsetId' => _('section-create'),'text' => _('Add')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-submit-loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-lg w--30 me-5','form_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('section-create-form')),'fieldset_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('section-create')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Add'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <button type="button" class="btn btn-secondary btn-lg w--30" id="btn-section-cancel-create">Cancel</button>
                    <small id="section-create-error-notice" class="text-danger mt-3"></small>
                </div>
            </div>

            <div class="col-sm-4 mx-auto">
                <div class="bg-light p-4 rounded">
                    <label class="col-sm-3 col-form-label-sm text-start text-second-color fw-bold">Section list</label>
                    <ul>
                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($section['name']); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </fieldset>
</form><?php /**PATH D:\Work\Git\ferry_backend\resources\views/pages/stations/section_create.blade.php ENDPATH**/ ?>