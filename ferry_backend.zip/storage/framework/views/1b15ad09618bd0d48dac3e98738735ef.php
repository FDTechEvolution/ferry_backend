

<?php $__env->startSection('page-title'); ?>
    <h1 class="ms-2 mb-0" id="station-page-title"><span class="text-main-color-2">Add</span> Section</h1>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.a-href-orange','data' => ['text' => _('Manage Section'),'href' => route('manage-section'),'target' => _('_self'),'class' => 'ms-3 btn-sm w--15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('a-href-orange'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Manage Section')),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('manage-section')),'target' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('_self')),'class' => 'ms-3 btn-sm w--15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-4">
    <div class="col-12">
        <form novalidate class="bs-validate" id="section-create-form" method="POST" action="<?php echo e(route('section-create')); ?>">
            <?php echo csrf_field(); ?>
            <fieldset id="section-create">
                <div class="row bg-transparent mt-5">
                    <div class="col-sm-4 mx-auto">
                        <h1 class="fw-bold text-second-color mb-4">Add new section</h1>

                        <div class="mb-4 row">
                            <label for="section-create-name" class="col-sm-3 col-form-label-sm text-start">Section* :</label>
                            <div class="col-sm-9">
                                <input type="text" required class="form-control form-control-sm" id="section-create-name" name="name" value="">
                            </div>
                        </div>

                        <div class="text-center mt-5">
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-submit-loading','data' => ['class' => 'btn-lg w--30 me-5','formId' => _('section-create-form'),'fieldsetId' => _('section-create'),'text' => _('Add')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-submit-loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-lg w--30 me-5','form_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('section-create-form')),'fieldset_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('section-create')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Add'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            <a href="<?php echo e(route('stations-index')); ?>" class="btn btn-secondary btn-lg w--30">Cancel</a>
                            <small id="section-create-error-notice" class="text-danger mt-3"></small>
                        </div>
                    </div>

                    <div class="col-sm-5 mx-auto">
                        <div class="bg-light p-4 rounded">
                            <label class="col-form-label-sm text-start text-second-color fw-bold">Section list</label>
                            <ul>
                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($section['name']); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/app/station.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Git\ferry_backend\resources\views/pages/stations/section_create.blade.php ENDPATH**/ ?>