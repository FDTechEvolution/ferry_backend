<div class="prow">
    <table class="w-100 ptable">
        <tr>
            <td class="w-100 header" style="padding: 0px;">
                <div class="">

                    <table class="w-100 ptable">
                        <tr>
                            <td style="width: 88%;padding-top:30px;" class="text-end">
                                <h2 class="text-white">ONLINE BOOKING ITENERY</h2>
                            </td>
                            <td class="text-end" style="height: 100px;">
                                <div style="float: right;display:block;margin-top:32px;">
                                    <?= DNS2D::getBarcodeHTML('4445645656', 'QRCODE', 2.5, 2.5, 'white') ?>
                                </div>

                            </td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
    </table>
</div>
