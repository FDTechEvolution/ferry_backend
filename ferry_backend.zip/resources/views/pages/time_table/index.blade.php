@extends('layouts.default')

@section('page-title')
@stop

@section('content')
@stop

@section('script')
@stop