<!-- Core javascripts -->
<script src="<?php echo e(asset('assets/js/core.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor_bundle.min.js')); ?>"></script><?php /**PATH D:\Work\Git\ferry_backend\resources\views/includes/script.blade.php ENDPATH**/ ?>